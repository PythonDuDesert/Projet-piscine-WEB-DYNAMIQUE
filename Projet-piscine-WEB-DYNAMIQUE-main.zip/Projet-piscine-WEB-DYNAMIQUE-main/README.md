# Projet-piscine-WEB-DYNAMIQUE

Léonard FORESTIER - Mike LIN - Julien MENET - Olivier YAMMINE
<br>ING2 Groupe 5 - PROMO 2028

<br>Admin:<br>
-olivier.yammine@edu.ece.fr
-olivier1234

-leonard.forestier@edu.ece.fr
-leonard1234

-julien.menet2@edu.ece.fr
-julien1234

-mike.lin@edu.ece.fr
-mike1234

<br>Credits:
    <br>-logo.png : ChatGPT
    <br>-greek-temple-ruins.jpg : Freepik
    <br>-Chariot icônes créées par Bogdan Rosu - Flaticon
    <br>-Utilisateur icônes créées par Freepik - Flaticon
    <br>-Notification icônes créées par Cuputo - Flaticon
    <br>-Bouton d'accueil icônes créées par FR_Media - Flaticon
    <br>-Livre icônes créées par Freepik - Flaticon
    <br>-Poignée de main de partenariat icônes créées par Iconjam - Flaticon
    <br>-Ajouter au chariot icônes créées par Pixel perfect - Flaticon
    <br>-Enchères icônes créées par meaicon - Flaticon
    <br>-Alerte icône créé par par Freepik - Flaticon
    <br>-Cash icons created by kerismaker - Flaticon
    <br>-Purchase icons created by Pixel perfect - Flaticon
    <br>-Inspiration pour les boutons : https://getcssscan.com/css-buttons-examples
    <br>-https://www.naturabuy.fr/Statue-Anubis-socle-Egypte--item-11396744.html
    <br>https://fr.freepik.com/vecteurs-libre/illustration-vectorielle-vintage-pot-creme-remixee-partir-oeuvre-john-matulis_17201206.htm#from_element=cross_selling__vector
    <br>-https://fr.freepik.com/images-ia-gratuites/ancien-recipient-poterie-au-design-retro_201646381.htm#fromView=search&page=3&position=41&uuid=6a74216b-e32d-47aa-bccc-de9ca468f1a0&query=object+egypt
    <br>-https://fr.freepik.com/images-ia-gratuites/vase-terre-cuite-motif-indigene_209409731.htm#fromView=search&page=5&position=8&uuid=6a74216b-e32d-47aa-bccc-de9ca468f1a0&query=object+egypt
    <br>-https://www.antiques-delaval.com/fr/faience-autres/1848-goulet-vase-pot-cruxhe-terre-egypte-antique-vessel.html
    <br>-https://fr.wikipedia.org/wiki/Religion_de_l%27%C3%89gypte_antique#/media/Fichier:Stele_Ra-Horakhty_Louvre_N3795-Egypte_louvre_047_stele.jpg
    <br>-https://www.antiques-delaval.com/fr/archeologie/18085-lampe-a-huile-antique-romaine-terre-cuite-afrique-du-nord-egypte-algerie.html
    <br>-https://www.antiques-delaval.com/fr/archeologie/18061-statuette-amulette-funeraire-egyptienne-egypte-terre-cuite-dieu-pretre-.html
    <br>-https://fr.wikipedia.org/wiki/Anubis#/media/Fichier:Anubis_standing.svg
    <br>-https://www.mv-bracelet.com/osiris/
    <br>-https://mythologica.fr/egypte/isis.htm
    <br>-https://fr.wikipedia.org/wiki/Horus#/media/Fichier:Horus_standing.svg
    <br>-https://fr.wikipedia.org/wiki/Seth#/media/Fichier:Set.svg
    <br>-https://fr.wikipedia.org/wiki/R%C3%AA#/media/Fichier:Re-Horakhty.svg
    <br>-https://fr.pngtree.com/freepng/old-book-cover-isolated-with-clipping-path-for-mockup_17407296.html
    <br>-https://fr.freepik.com/photos-gratuite/couverture-livre-vierge-antique-cuir-marron-espace-design_21631149.htm#fromView=search&page=1&position=4&uuid=df9d9ea8-5547-450a-bfa5-0d73f717e225&query=Livre+Ancien
    <br>-https://fr.freepik.com/photos-gratuite/marque-pages-lin-dans-vieux-cahier_2041514.htm#fromView=search&page=1&position=6&uuid=df9d9ea8-5547-450a-bfa5-0d73f717e225&query=Livre+Ancien
    <br>-Augmentation de la taille du bouton d'alerte "scale();"
    <br>-https://developer.mozilla.org/fr/docs/Web/CSS/transform-function/scale

    <br>-Réutilisation des TD/TP.

<br>https://www.canva.com/design/DAGocZUzkAM/0UeqUDhHJh4JXr84gPCwfg/edit
